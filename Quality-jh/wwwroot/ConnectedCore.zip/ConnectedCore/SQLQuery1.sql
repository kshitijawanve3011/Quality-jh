﻿create database ConnectedDB;
use ConnectedDB;

drop table Bill1(
bill1ID int primary key identity(1,1),
billName nvarchar(max),
name nvarchar(max)
);
drop table Bill2(
bill2ID int primary key identity(1,1),
billName nvarchar(max),
name nvarchar(max), 
fbill2id int REFERENCES Bill1(bill1ID)
);
drop table Bill3(
bill3ID int primary key identity(1,1),
billName nvarchar(max),
name nvarchar(max),
fbill3id int REFERENCES Bill2(bill2ID)
);

sp_help bill3;

  CREATE TABLE [dbo].[Vendorbill1](
	[Vendor1Id] [int] primary key IDENTITY(1,1) NOT NULL,
	[Department] [varchar](100) NULL,
	[VendorName] [varchar](100) NULL,
	[WorkOrderNoPONO] [nvarchar](100) NULL,
	[ContractStartDate] [datetime] NULL,
	[ContractEndDate] [datetime] NULL,
	[BillingPeriod] [varchar](100) NULL,
	[BillType_Id] [int] NULL,
	[Service] [varchar](100) NULL
);

CREATE TABLE [dbo].[Vendorbill2](
	ID int primary key identity(1,1),
	[vendor2Id] [int] REFERENCES Vendorbill1(Vendor1Id),
	[InvoiceNO] [nvarchar](100) NULL,
	[Date] [datetime] NULL,
	[BillSubmit] [date] NULL,
	[BillType_Id] [int] NULL
	);

	CREATE TABLE [dbo].[Vendorbill3](
	ID int primary key identity(1,1),
	[vendor3Id] [int] REFERENCES Vendorbill1(Vendor1Id),
	[ActiveInactive] [bit] NULL,
	[UTRNO] [varchar](100) NULL,
	[Date] [datetime] NULL,
	[AmountPaid] [int] NULL,
	[BillType_Id] [int] NULL
);
  
