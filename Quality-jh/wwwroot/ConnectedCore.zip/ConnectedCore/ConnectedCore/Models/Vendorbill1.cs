﻿using System;
using System.Collections.Generic;

namespace ConnectedCore.Models;

public partial class Vendorbill1
{
    public int Vendor1Id { get; set; }

    public string? Department { get; set; }

    public string? VendorName { get; set; }

    public string? WorkOrderNoPono { get; set; }

    public DateTime? ContractStartDate { get; set; }

    public DateTime? ContractEndDate { get; set; }

    public string? BillingPeriod { get; set; }

    public int? BillTypeId { get; set; }

    public string? Service { get; set; }

    public virtual ICollection<Vendorbill2> Vendorbill2s { get; set; } = new List<Vendorbill2>();

    public virtual ICollection<Vendorbill3> Vendorbill3s { get; set; } = new List<Vendorbill3>();
}
