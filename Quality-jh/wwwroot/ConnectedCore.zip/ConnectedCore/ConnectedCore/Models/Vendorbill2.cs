﻿using System;
using System.Collections.Generic;

namespace ConnectedCore.Models;

public partial class Vendorbill2
{
    public int Id { get; set; }

    public int? Vendor2Id { get; set; }

    public string? InvoiceNo { get; set; }

    public DateTime? Date { get; set; }

    public DateOnly? BillSubmit { get; set; }

    public int? BillTypeId { get; set; }

    public virtual Vendorbill1? Vendor2 { get; set; }
}
