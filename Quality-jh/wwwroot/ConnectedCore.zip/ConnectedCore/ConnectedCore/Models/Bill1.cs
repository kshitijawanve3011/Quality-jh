﻿using System;
using System.Collections.Generic;

namespace ConnectedCore.Models;

public partial class Bill1
{
    public int Bill1Id { get; set; }

    public string? BillName { get; set; }

    public string? Name { get; set; }
}
