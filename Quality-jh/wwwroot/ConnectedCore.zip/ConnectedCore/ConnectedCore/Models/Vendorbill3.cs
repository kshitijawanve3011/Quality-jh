﻿using System;
using System.Collections.Generic;

namespace ConnectedCore.Models;

public partial class Vendorbill3
{
    public int Id { get; set; }

    public int? Vendor3Id { get; set; }

    public bool? ActiveInactive { get; set; }

    public string? Utrno { get; set; }

    public DateTime? Date { get; set; }

    public int? AmountPaid { get; set; }

    public int? BillTypeId { get; set; }

    public virtual Vendorbill1? Vendor3 { get; set; }
}
