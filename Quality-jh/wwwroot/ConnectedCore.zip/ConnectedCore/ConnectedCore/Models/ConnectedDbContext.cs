﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ConnectedCore.Models;

public partial class ConnectedDbContext : DbContext
{
    public ConnectedDbContext()
    {
    }
    /*
     Scaffold-DbContext "Server=(localdb)\ProjectModels;Database=ConnectedDB;Trusted_Connection=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models
     */
    public ConnectedDbContext(DbContextOptions<ConnectedDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Bill1> Bill1s { get; set; }

    public virtual DbSet<Vendorbill1> Vendorbill1s { get; set; }

    public virtual DbSet<Vendorbill2> Vendorbill2s { get; set; }

    public virtual DbSet<Vendorbill3> Vendorbill3s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\ProjectModels;Database=ConnectedDB;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Bill1>(entity =>
        {
            entity.HasKey(e => e.Bill1Id).HasName("PK__Bill1__38E530CA88B6A16D");

            entity.ToTable("Bill1");

            entity.Property(e => e.Bill1Id).HasColumnName("bill1ID");
            entity.Property(e => e.BillName).HasColumnName("billName");
            entity.Property(e => e.Name).HasColumnName("name");
        });

        modelBuilder.Entity<Vendorbill1>(entity =>
        {
            entity.HasKey(e => e.Vendor1Id).HasName("PK__Vendorbi__095CC17CAD7F2748");

            entity.ToTable("Vendorbill1");

            entity.Property(e => e.BillTypeId).HasColumnName("BillType_Id");
            entity.Property(e => e.BillingPeriod)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContractEndDate).HasColumnType("datetime");
            entity.Property(e => e.ContractStartDate).HasColumnType("datetime");
            entity.Property(e => e.Department)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Service)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.VendorName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.WorkOrderNoPono)
                .HasMaxLength(100)
                .HasColumnName("WorkOrderNoPONO");
        });

        modelBuilder.Entity<Vendorbill2>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Vendorbi__3214EC275C1DFC25");

            entity.ToTable("Vendorbill2");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BillTypeId).HasColumnName("BillType_Id");
            entity.Property(e => e.Date).HasColumnType("datetime");
            entity.Property(e => e.InvoiceNo)
                .HasMaxLength(100)
                .HasColumnName("InvoiceNO");
            entity.Property(e => e.Vendor2Id).HasColumnName("vendor2Id");

            entity.HasOne(d => d.Vendor2).WithMany(p => p.Vendorbill2s)
                .HasForeignKey(d => d.Vendor2Id)
                .HasConstraintName("FK__Vendorbil__vendo__4F7CD00D");
        });

        modelBuilder.Entity<Vendorbill3>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Vendorbi__3214EC279AAF8E1A");

            entity.ToTable("Vendorbill3");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.BillTypeId).HasColumnName("BillType_Id");
            entity.Property(e => e.Date).HasColumnType("datetime");
            entity.Property(e => e.Utrno)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("UTRNO");
            entity.Property(e => e.Vendor3Id).HasColumnName("vendor3Id");

            entity.HasOne(d => d.Vendor3).WithMany(p => p.Vendorbill3s)
                .HasForeignKey(d => d.Vendor3Id)
                .HasConstraintName("FK__Vendorbil__vendo__52593CB8");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
