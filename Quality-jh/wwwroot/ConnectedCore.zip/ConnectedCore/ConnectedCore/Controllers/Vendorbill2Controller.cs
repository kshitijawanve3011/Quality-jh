﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ConnectedCore.Models;

namespace ConnectedCore.Controllers
{
    public class Vendorbill2Controller : Controller
    {
        private readonly ConnectedDbContext _context;

        public Vendorbill2Controller(ConnectedDbContext context)
        {
            _context = context;
        }

        // GET: Vendorbill2
        public async Task<IActionResult> Index()
        {
            var connectedDbContext = _context.Vendorbill2s.Include(v => v.Vendor2);
            return View(await connectedDbContext.ToListAsync());
        }

        // GET: Vendorbill2/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill2 = await _context.Vendorbill2s
                .Include(v => v.Vendor2)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vendorbill2 == null)
            {
                return NotFound();
            }

            return View(vendorbill2);
        }

        // GET: Vendorbill2/Create
        public IActionResult Create()
        {
            ViewData["Vendor2Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id");
            return View();
        }

        // POST: Vendorbill2/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Vendor2Id,InvoiceNo,Date,BillSubmit,BillTypeId")] Vendorbill2 vendorbill2)
        {
            if (ModelState.IsValid)
            {
                _context.Add(vendorbill2);
                await _context.SaveChangesAsync();
                return RedirectToAction("Create","Vendorbill3");
            }
            ViewData["Vendor2Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill2.Vendor2Id);
            return View(vendorbill2);
        }

        // GET: Vendorbill2/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill2 = await _context.Vendorbill2s.FindAsync(id);
            if (vendorbill2 == null)
            {
                return NotFound();
            }
            ViewData["Vendor2Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill2.Vendor2Id);
            return View(vendorbill2);
        }

        // POST: Vendorbill2/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Vendor2Id,InvoiceNo,Date,BillSubmit,BillTypeId")] Vendorbill2 vendorbill2)
        {
            if (id != vendorbill2.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vendorbill2);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Vendorbill2Exists(vendorbill2.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Vendor2Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill2.Vendor2Id);
            return View(vendorbill2);
        }

        // GET: Vendorbill2/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill2 = await _context.Vendorbill2s
                .Include(v => v.Vendor2)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vendorbill2 == null)
            {
                return NotFound();
            }

            return View(vendorbill2);
        }

        // POST: Vendorbill2/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vendorbill2 = await _context.Vendorbill2s.FindAsync(id);
            if (vendorbill2 != null)
            {
                _context.Vendorbill2s.Remove(vendorbill2);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Vendorbill2Exists(int id)
        {
            return _context.Vendorbill2s.Any(e => e.Id == id);
        }
    }
}
