﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ConnectedCore.Models;

namespace ConnectedCore.Controllers
{
    public class Vendorbill3Controller : Controller
    {
        private readonly ConnectedDbContext _context;

        public Vendorbill3Controller(ConnectedDbContext context)
        {
            _context = context;
        }

        // GET: Vendorbill3
        public async Task<IActionResult> Index()
        {
            var connectedDbContext = _context.Vendorbill3s.Include(v => v.Vendor3);
            return View(await connectedDbContext.ToListAsync());
        }

        // GET: Vendorbill3/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill3 = await _context.Vendorbill3s
                .Include(v => v.Vendor3)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vendorbill3 == null)
            {
                return NotFound();
            }

            return View(vendorbill3);
        }

        // GET: Vendorbill3/Create
        public IActionResult Create()
        {
            ViewData["Vendor3Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id");
            return View();
        }

        // POST: Vendorbill3/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Vendor3Id,ActiveInactive,Utrno,Date,AmountPaid,BillTypeId")] Vendorbill3 vendorbill3)
        {
            if (ModelState.IsValid)
            {
                _context.Add(vendorbill3);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Vendor3Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill3.Vendor3Id);
            return View(vendorbill3);
        }

        // GET: Vendorbill3/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill3 = await _context.Vendorbill3s.FindAsync(id);
            if (vendorbill3 == null)
            {
                return NotFound();
            }
            ViewData["Vendor3Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill3.Vendor3Id);
            return View(vendorbill3);
        }

        // POST: Vendorbill3/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Vendor3Id,ActiveInactive,Utrno,Date,AmountPaid,BillTypeId")] Vendorbill3 vendorbill3)
        {
            if (id != vendorbill3.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(vendorbill3);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!Vendorbill3Exists(vendorbill3.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Vendor3Id"] = new SelectList(_context.Vendorbill1s, "Vendor1Id", "Vendor1Id", vendorbill3.Vendor3Id);
            return View(vendorbill3);
        }

        // GET: Vendorbill3/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vendorbill3 = await _context.Vendorbill3s
                .Include(v => v.Vendor3)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (vendorbill3 == null)
            {
                return NotFound();
            }

            return View(vendorbill3);
        }

        // POST: Vendorbill3/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vendorbill3 = await _context.Vendorbill3s.FindAsync(id);
            if (vendorbill3 != null)
            {
                _context.Vendorbill3s.Remove(vendorbill3);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Vendorbill3Exists(int id)
        {
            return _context.Vendorbill3s.Any(e => e.Id == id);
        }
    }
}
